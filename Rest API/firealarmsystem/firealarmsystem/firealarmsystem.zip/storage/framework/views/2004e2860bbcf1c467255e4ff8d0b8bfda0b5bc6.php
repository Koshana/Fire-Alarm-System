<div class="page-header bg-white">
    <div class="container">
        <div class="row">
            <table class="table table-bordered text-dark">
                <tr class="text-center">
                    <th>#</th>
                    <th>Floor</th>
                    <th>Room</th>
                    <th>Status</th>
                </tr>
                <tbody>
                    <tr>
                        <td>1</td>
                        <td>2</td>
                        <td>14</td>
                        <td class="text-center">
                            <svg height="30" width="30">
                                <circle cx="20" cy="20" r="10" stroke="white" stroke-width="3" fill="red" />
                              </svg>
                        </td>
                    </tr>
                    <tr>
                        <td>2</td>
                        <td>2</td>
                        <td>12</td>
                        <td class="text-center">
                            <svg height="30" width="30">
                                <circle cx="20" cy="20" r="10" stroke="white" stroke-width="3" fill="green" />
                              </svg>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
<?php /**PATH E:\Developments\Laravel Projects\firealarmsystem\resources\views/datatable.blade.php ENDPATH**/ ?>